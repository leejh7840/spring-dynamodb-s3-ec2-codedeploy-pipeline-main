#!/usr/bin/env bash
chmod +x /home/ec2-user/server/*.jar
