#!/usr/bin/env bash
sudo pkill -f 'java -jar'